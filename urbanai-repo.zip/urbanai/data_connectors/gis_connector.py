"""
GIS Connector — Spatial data retrieval for map overlays and geospatial queries.
Interfaces with OpenStreetMap, ArcGIS, and campus GIS layers.
"""

import json
import numpy as np
from loguru import logger


class GISConnector:
    """
    Provides GeoJSON data for dashboard map visualizations.
    In production, connects to ArcGIS Enterprise or PostGIS.
    """
    
    # Campus center (example: IIT Delhi area)
    CAMPUS_CENTER = {"lat": 28.5450, "lng": 77.1926}
    
    def __init__(self):
        logger.info("GISConnector initialized")

    def get_geojson(self, query_type: str, bounds: str = None) -> dict:
        generators = {
            "occupancy_heatmap": self._occupancy_heatmap,
            "footfall_flow": self._footfall_flow_geojson,
            "clog_points": self._clog_points_geojson,
            "water_zones": self._water_zones_geojson,
            "greenery_zones": self._greenery_zones_geojson,
            "parking_status": self._parking_status_geojson,
        }
        generator = generators.get(query_type, self._occupancy_heatmap)
        return generator()

    def _occupancy_heatmap(self) -> dict:
        """Generate heatmap points for space occupancy."""
        clat, clng = self.CAMPUS_CENTER["lat"], self.CAMPUS_CENTER["lng"]
        features = []
        zones = [
            ("Block A - Classrooms", 0.001, 0.001, 0.85),
            ("Block B - Labs", -0.001, 0.002, 0.45),
            ("Library", 0.002, -0.001, 0.70),
            ("Cafeteria", 0.000, 0.000, 0.95),
            ("Sports Complex", -0.002, -0.002, 0.30),
            ("Admin Block", 0.003, 0.001, 0.60),
        ]
        for name, dlat, dlng, occ in zones:
            features.append({
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [clng + dlng, clat + dlat]},
                "properties": {"name": name, "occupancy": occ, "intensity": occ},
            })
        return {"type": "FeatureCollection", "features": features, "query_type": "occupancy_heatmap"}

    def _footfall_flow_geojson(self) -> dict:
        """Generate flow arrows for pedestrian movement."""
        clat, clng = self.CAMPUS_CENTER["lat"], self.CAMPUS_CENTER["lng"]
        features = []
        flows = [
            ("Main Gate → Academic Block", [clng, clat], [clng + 0.002, clat + 0.001], 850),
            ("Academic Block → Cafeteria", [clng + 0.002, clat + 0.001], [clng + 0.001, clat - 0.001], 620),
            ("Cafeteria → Library", [clng + 0.001, clat - 0.001], [clng + 0.003, clat], 280),
        ]
        for name, start, end, volume in flows:
            features.append({
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": [start, end]},
                "properties": {"name": name, "volume_pph": volume, "width": volume / 200},
            })
        return {"type": "FeatureCollection", "features": features, "query_type": "footfall_flow"}

    def _clog_points_geojson(self) -> dict:
        clat, clng = self.CAMPUS_CENTER["lat"], self.CAMPUS_CENTER["lng"]
        clog_locations = [
            ("Main Gate Bottleneck", clng - 0.001, clat - 0.001, "CRITICAL", 1.05),
            ("Cafeteria Junction", clng + 0.001, clat + 0.001, "HIGH", 0.88),
            ("Hostel Road Crossing", clng + 0.003, clat + 0.002, "MEDIUM", 0.72),
        ]
        features = []
        for name, lng, lat, severity, util in clog_locations:
            features.append({
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [lng, lat]},
                "properties": {"name": name, "severity": severity, "utilization": util,
                               "color": "#FF0000" if severity == "CRITICAL" else "#FF8C00" if severity == "HIGH" else "#FFD700"},
            })
        return {"type": "FeatureCollection", "features": features, "query_type": "clog_points"}

    def _water_zones_geojson(self) -> dict:
        clat, clng = self.CAMPUS_CENTER["lat"], self.CAMPUS_CENTER["lng"]
        zones = [
            ("Zone Z1 - Academic", clng + 0.001, clat + 0.001, 0.001, "GOOD"),
            ("Zone Z2 - Hostels", clng - 0.001, clat + 0.002, 0.0015, "WARNING"),
            ("Zone Z4 - Irrigation", clng + 0.002, clat - 0.002, 0.002, "CRITICAL"),
        ]
        features = []
        for name, lng, lat, r, status in zones:
            # Approximate circle as polygon
            angles = np.linspace(0, 2 * np.pi, 20)
            coords = [[lng + r * np.cos(a), lat + r * np.sin(a)] for a in angles]
            coords.append(coords[0])
            features.append({
                "type": "Feature",
                "geometry": {"type": "Polygon", "coordinates": [coords]},
                "properties": {"name": name, "status": status,
                               "color": "#00C851" if status == "GOOD" else "#FF8800" if status == "WARNING" else "#FF0000"},
            })
        return {"type": "FeatureCollection", "features": features, "query_type": "water_zones"}

    def _greenery_zones_geojson(self) -> dict:
        clat, clng = self.CAMPUS_CENTER["lat"], self.CAMPUS_CENTER["lng"]
        zones = [
            ("Central Green", clng + 0.001, clat, 0.002, 0.72),
            ("Sports Field Perimeter", clng - 0.002, clat - 0.001, 0.001, 0.45),
            ("North Campus Plantation", clng, clat + 0.003, 0.0015, 0.88),
        ]
        features = []
        for name, lng, lat, r, greenery_index in zones:
            angles = np.linspace(0, 2 * np.pi, 16)
            coords = [[lng + r * np.cos(a), lat + r * np.sin(a)] for a in angles]
            coords.append(coords[0])
            features.append({
                "type": "Feature",
                "geometry": {"type": "Polygon", "coordinates": [coords]},
                "properties": {"name": name, "greenery_index": greenery_index,
                               "color": f"rgba(34, {int(139 + greenery_index * 80)}, 34, 0.5)"},
            })
        return {"type": "FeatureCollection", "features": features, "query_type": "greenery_zones"}

    def _parking_status_geojson(self) -> dict:
        clat, clng = self.CAMPUS_CENTER["lat"], self.CAMPUS_CENTER["lng"]
        lots = [
            ("P1 Main Gate", clng - 0.001, clat - 0.001, 0.92),
            ("P2 Academic", clng + 0.0015, clat + 0.001, 0.55),
            ("P3 Sports", clng - 0.002, clat + 0.002, 0.28),
        ]
        features = []
        for name, lng, lat, occ in lots:
            color = "#FF0000" if occ > 0.9 else "#FF8C00" if occ > 0.7 else "#00C851"
            features.append({
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [lng, lat]},
                "properties": {"name": name, "occupancy": occ, "color": color,
                               "status": "FULL" if occ > 0.9 else "BUSY" if occ > 0.7 else "FREE"},
            })
        return {"type": "FeatureCollection", "features": features, "query_type": "parking_status"}
