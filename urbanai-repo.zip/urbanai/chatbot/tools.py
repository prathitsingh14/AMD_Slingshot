"""
UrbanAI Chatbot Tools
LangChain tool definitions that the LLM can call to query domain ML models and live data.
"""

from langchain_core.tools import tool
from typing import Optional
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


@tool
def query_space_utilization(
    location: str,
    time_horizon_hours: int = 24,
    space_type: str = "all"
) -> dict:
    """
    Query space utilization analytics for a campus location.
    Returns occupancy rates, predicted peak times, and optimization recommendations.
    
    Args:
        location: Building name, zone, or 'campus-wide'
        time_horizon_hours: Forecast horizon (1-168 hours)
        space_type: 'classroom' | 'lab' | 'parking' | 'sports' | 'all'
    """
    from models.space_utilization.predictor import SpaceUtilizationPredictor
    predictor = SpaceUtilizationPredictor.load_default()
    return predictor.predict(location=location, hours=time_horizon_hours, space_type=space_type)


@tool
def query_footfall_clog(
    zone: str,
    detect_clog_points: bool = True,
    time_of_day: Optional[str] = None
) -> dict:
    """
    Analyze pedestrian footfall and detect traffic clog points in a campus/city zone.
    Returns flow rates, identified bottlenecks, and routing recommendations.
    
    Args:
        zone: Zone name, gate name, or 'all'
        detect_clog_points: Whether to run clog detection algorithm
        time_of_day: 'morning' | 'afternoon' | 'evening' | 'night' | None (current)
    """
    from models.footfall.analyzer import FootfallAnalyzer
    analyzer = FootfallAnalyzer.load_default()
    return analyzer.analyze(zone=zone, detect_clogs=detect_clog_points, time_of_day=time_of_day)


@tool
def query_waste_prediction(
    area: str,
    waste_type: str = "biodegradable",
    days_ahead: int = 7
) -> dict:
    """
    Predict waste generation and recommend biodegradable waste optimization strategies.
    Returns waste volume forecasts, biogas yield estimates, and collection schedule.
    
    Args:
        area: Campus zone or city area name
        waste_type: 'biodegradable' | 'recyclable' | 'mixed' | 'all'
        days_ahead: Forecast horizon in days
    """
    from models.waste_water.waste_predictor import WastePredictor
    predictor = WastePredictor.load_default()
    return predictor.predict(area=area, waste_type=waste_type, days=days_ahead)


@tool
def query_water_treatment(
    zone: str,
    sensor_data: Optional[dict] = None
) -> dict:
    """
    Analyze water system data and recommend treatment installations or interventions.
    Detects anomalies in pipeline sensor data and flags water quality issues.
    
    Args:
        zone: Water zone or pipeline segment ID
        sensor_data: Optional live sensor readings dict (pH, turbidity, flow_rate, pressure)
    """
    from models.waste_water.water_analyzer import WaterAnalyzer
    analyzer = WaterAnalyzer.load_default()
    return analyzer.analyze(zone=zone, sensor_data=sensor_data)


@tool
def query_greenery_recommendation(
    location: str,
    soil_data: Optional[dict] = None,
    area_sqm: Optional[float] = None
) -> dict:
    """
    Recommend suitable plants and greenery solutions based on soil analysis and location context.
    Returns plant species recommendations, soil improvement suggestions, and planting layout.
    
    Args:
        location: GPS coordinates string "lat,lng" or location name
        soil_data: Optional soil sensor readings (pH, moisture, nitrogen, phosphorus, potassium)
        area_sqm: Area to be planted in square meters
    """
    from models.greenery.recommender import GreeneryRecommender
    recommender = GreeneryRecommender.load_default()
    return recommender.recommend(location=location, soil_data=soil_data, area_sqm=area_sqm)


@tool
def query_parking_availability(
    lot_id: str = "all",
    forecast_hours: int = 2
) -> dict:
    """
    Get real-time parking availability and predict future occupancy.
    Returns current counts, predicted availability, and optimal routing.
    
    Args:
        lot_id: Parking lot ID or 'all' for campus-wide
        forecast_hours: Hours ahead to forecast
    """
    from models.space_utilization.parking import ParkingPredictor
    predictor = ParkingPredictor.load_default()
    return predictor.get_availability(lot_id=lot_id, forecast_hours=forecast_hours)


@tool
def query_spatial_map(
    query_type: str,
    bounds: Optional[str] = None
) -> dict:
    """
    Generate spatial map data for visualization — heatmaps, flow maps, zone overlays.
    Returns GeoJSON data ready for dashboard rendering.
    
    Args:
        query_type: 'occupancy_heatmap' | 'footfall_flow' | 'clog_points' | 
                    'water_zones' | 'greenery_zones' | 'parking_status'
        bounds: Optional bounding box "min_lat,min_lng,max_lat,max_lng"
    """
    from data_connectors.gis_connector import GISConnector
    gis = GISConnector()
    return gis.get_geojson(query_type=query_type, bounds=bounds)
