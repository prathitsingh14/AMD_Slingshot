"""
IoT Sensor Connector — MQTT-based real-time sensor data ingestion.
Handles footfall counters, parking sensors, water quality probes, and soil sensors.
"""

import asyncio
import json
from datetime import datetime
from collections import defaultdict, deque
from loguru import logger


class SensorDataBuffer:
    """Thread-safe circular buffer for sensor readings."""
    
    def __init__(self, maxlen: int = 1000):
        self._data: dict[str, deque] = defaultdict(lambda: deque(maxlen=maxlen))
    
    def push(self, topic: str, payload: dict):
        self._data[topic].append({**payload, "ingested_at": datetime.now().isoformat()})
    
    def latest(self, topic: str) -> dict | None:
        return self._data[topic][-1] if self._data[topic] else None
    
    def history(self, topic: str, n: int = 100) -> list:
        return list(self._data[topic])[-n:]
    
    def all_topics(self) -> list[str]:
        return list(self._data.keys())


class IoTConnector:
    """
    Connects to MQTT broker and ingests sensor data.
    
    Topics consumed:
        campus/footfall/{zone_id}       → {count, direction, timestamp}
        campus/parking/{lot_id}         → {occupied, capacity, timestamp}
        campus/water/{zone_id}          → {ph, turbidity, tds, chlorine, flow, pressure}
        campus/soil/{location_id}       → {ph, moisture, nitrogen, phosphorus, potassium}
        campus/waste/{bin_id}           → {fill_level_pct, weight_kg, timestamp}
    """
    
    TOPIC_SUBSCRIPTIONS = [
        "campus/footfall/#",
        "campus/parking/#",
        "campus/water/#",
        "campus/soil/#",
        "campus/waste/#",
    ]

    def __init__(self, broker: str, port: int = 1883, 
                 username: str = None, password: str = None):
        self.broker = broker
        self.port = port
        self.username = username
        self.password = password
        self.buffer = SensorDataBuffer()
        self._client = None
        self._connected = False

    async def connect(self):
        try:
            import asyncio_mqtt as aiomqtt
            
            async with aiomqtt.Client(
                hostname=self.broker,
                port=self.port,
                username=self.username,
                password=self.password,
            ) as client:
                self._connected = True
                logger.info(f"MQTT connected to {self.broker}:{self.port}")
                
                for topic in self.TOPIC_SUBSCRIPTIONS:
                    await client.subscribe(topic)
                    logger.info(f"Subscribed: {topic}")
                
                async for message in client.messages:
                    await self._handle_message(str(message.topic), message.payload)
        
        except Exception as e:
            logger.error(f"MQTT connection failed: {e}")
            self._connected = False

    async def _handle_message(self, topic: str, payload: bytes):
        try:
            data = json.loads(payload.decode("utf-8"))
            self.buffer.push(topic, data)
            logger.debug(f"Received [{topic}]: {data}")
        except json.JSONDecodeError:
            logger.warning(f"Invalid JSON on topic {topic}")

    def get_latest_reading(self, sensor_type: str, zone_id: str) -> dict | None:
        topic = f"campus/{sensor_type}/{zone_id}"
        return self.buffer.latest(topic)

    def get_all_latest(self) -> dict:
        """Get latest reading from every active sensor."""
        result = {}
        for topic in self.buffer.all_topics():
            parts = topic.split("/")
            if len(parts) >= 3:
                sensor_type, zone_id = parts[1], parts[2]
                result.setdefault(sensor_type, {})[zone_id] = self.buffer.latest(topic)
        return result

    @property
    def is_connected(self) -> bool:
        return self._connected


class MockIoTConnector(IoTConnector):
    """
    Mock connector for development/testing without a real MQTT broker.
    Generates realistic synthetic sensor data.
    """
    
    def __init__(self):
        self.buffer = SensorDataBuffer()
        self._connected = True
        self._populate_mock_data()
        logger.info("MockIoTConnector initialized with synthetic data")

    def _populate_mock_data(self):
        import numpy as np
        
        # Footfall sensors
        for zone in ["main_gate", "cafeteria", "library", "academic_block"]:
            self.buffer.push(f"campus/footfall/{zone}", {
                "count": int(np.random.uniform(50, 400)),
                "direction": np.random.choice(["inbound", "outbound", "both"]),
                "timestamp": datetime.now().isoformat(),
            })
        
        # Parking sensors
        for lot in ["P1", "P2", "P3", "P4"]:
            cap = {"P1": 500, "P2": 300, "P3": 200, "P4": 150}[lot]
            occ = int(cap * np.random.uniform(0.2, 0.98))
            self.buffer.push(f"campus/parking/{lot}", {
                "occupied": occ, "capacity": cap, "available": cap - occ,
                "timestamp": datetime.now().isoformat(),
            })
        
        # Water sensors
        for zone in ["Z1", "Z2", "Z3", "Z4", "Z5"]:
            self.buffer.push(f"campus/water/{zone}", {
                "ph": round(np.random.uniform(6.0, 8.5), 2),
                "turbidity_ntu": round(abs(np.random.normal(2, 1.5)), 2),
                "tds_ppm": round(np.random.uniform(150, 700), 1),
                "chlorine_ppm": round(np.random.uniform(0.1, 1.2), 3),
                "flow_rate_lpm": round(np.random.uniform(20, 300), 1),
                "pressure_bar": round(np.random.uniform(1.0, 4.5), 2),
                "timestamp": datetime.now().isoformat(),
            })
        
        # Soil sensors
        for loc in ["central_garden", "north_plantation", "sports_perimeter"]:
            self.buffer.push(f"campus/soil/{loc}", {
                "ph": round(np.random.uniform(5.5, 8.0), 2),
                "moisture_pct": round(np.random.uniform(25, 80), 1),
                "nitrogen_ppm": round(np.random.uniform(10, 120), 1),
                "phosphorus_ppm": round(np.random.uniform(8, 70), 1),
                "potassium_ppm": round(np.random.uniform(60, 320), 1),
                "timestamp": datetime.now().isoformat(),
            })


def get_connector(use_mock: bool = False) -> IoTConnector:
    """Factory function — returns real or mock connector based on environment."""
    import os
    if use_mock or not os.getenv("MQTT_BROKER"):
        return MockIoTConnector()
    return IoTConnector(
        broker=os.getenv("MQTT_BROKER", "localhost"),
        port=int(os.getenv("MQTT_PORT", "1883")),
        username=os.getenv("MQTT_USERNAME"),
        password=os.getenv("MQTT_PASSWORD"),
    )
