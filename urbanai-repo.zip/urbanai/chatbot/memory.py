"""
Conversation Memory — manages per-session chat history with sliding window.
"""

from collections import defaultdict, deque
from langchain_core.messages import HumanMessage, AIMessage


class ConversationMemory:
    def __init__(self, max_history: int = 20):
        self.max_history = max_history
        self._sessions: dict[str, deque] = defaultdict(lambda: deque(maxlen=max_history))

    def add_exchange(self, session_id: str, user_msg: str, ai_msg: str):
        self._sessions[session_id].append(HumanMessage(content=user_msg))
        self._sessions[session_id].append(AIMessage(content=ai_msg))

    def get_history(self, session_id: str) -> list:
        return list(self._sessions[session_id])

    def clear(self, session_id: str):
        self._sessions[session_id].clear()

    def list_sessions(self) -> list[str]:
        return list(self._sessions.keys())
