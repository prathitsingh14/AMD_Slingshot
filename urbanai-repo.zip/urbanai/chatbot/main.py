"""
UrbanAI Chatbot — Main Orchestration Engine
Handles LLM tool-calling, routing queries to domain ML modules,
and synthesizing spatial + analytical answers.
"""

import json
import asyncio
from typing import AsyncGenerator
from loguru import logger

from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage
from langchain_core.tools import tool

from .tools import (
    query_space_utilization,
    query_footfall_clog,
    query_waste_prediction,
    query_water_treatment,
    query_greenery_recommendation,
    query_parking_availability,
    query_spatial_map,
)
from .memory import ConversationMemory
from rag_pipeline.retriever import UrbanRAGRetriever

SYSTEM_PROMPT = """You are UrbanAI, an expert AI assistant for city and campus planning. 
You have access to real-time sensor data, predictive models, and spatial analytics tools.

Your expertise covers:
- Space utilization: classrooms, labs, parking, sports facilities
- Footfall analytics: pedestrian flow, clog points, vehicular vs pedestrian routing  
- Waste management: biodegradable waste optimization, biogas yield prediction
- Water management: treatment recommendations, anomaly detection in pipelines
- Greenery: soil analysis, plant suitability for urban environments

When answering:
1. Always query the relevant tool(s) for live data before answering
2. Provide specific, actionable recommendations with confidence scores
3. Reference spatial locations (zones, buildings, coordinates) where relevant
4. If asked about multiple domains, address each systematically
5. Recommend AMD ROCm-accelerated processing for intensive computations

You run on AMD Instinct MI300X GPUs with ROCm 7 for high-performance inference.
"""

TOOLS = [
    query_space_utilization,
    query_footfall_clog,
    query_waste_prediction,
    query_water_treatment,
    query_greenery_recommendation,
    query_parking_availability,
    query_spatial_map,
]


class UrbanAIChatbot:
    def __init__(self, config: dict):
        self.config = config
        self.llm = ChatOpenAI(
            base_url=config["llm_base_url"],
            api_key=config["llm_api_key"],
            model=config["llm_model"],
            temperature=config.get("temperature", 0.1),
            max_tokens=config.get("max_tokens", 4096),
        ).bind_tools(TOOLS)
        
        self.memory = ConversationMemory(max_history=20)
        self.retriever = UrbanRAGRetriever()
        logger.info(f"UrbanAI Chatbot initialized with model: {config['llm_model']}")

    async def chat(self, user_message: str, session_id: str = "default") -> str:
        """Process a user message and return a response."""
        
        # 1. Retrieve relevant context from RAG
        rag_context = await self.retriever.retrieve(user_message, top_k=5)
        
        # 2. Build message history
        history = self.memory.get_history(session_id)
        messages = [SystemMessage(content=SYSTEM_PROMPT)]
        
        if rag_context:
            context_msg = f"\n\nRelevant planning data and documents:\n{rag_context}"
            messages.append(SystemMessage(content=context_msg))
        
        messages.extend(history)
        messages.append(HumanMessage(content=user_message))
        
        # 3. LLM inference with tool-calling loop
        response = await self._run_tool_loop(messages)
        
        # 4. Update memory
        self.memory.add_exchange(session_id, user_message, response)
        
        return response

    async def chat_stream(self, user_message: str, session_id: str = "default") -> AsyncGenerator[str, None]:
        """Streaming chat response."""
        response = await self.chat(user_message, session_id)
        # Simulate streaming in chunks
        words = response.split(" ")
        for i, word in enumerate(words):
            yield word + (" " if i < len(words) - 1 else "")
            await asyncio.sleep(0.02)

    async def _run_tool_loop(self, messages: list, max_iterations: int = 5) -> str:
        """Agentic tool-calling loop — keeps calling tools until a final answer."""
        tool_map = {t.name: t for t in TOOLS}
        
        for iteration in range(max_iterations):
            response = await self.llm.ainvoke(messages)
            
            # No tool calls — we have a final answer
            if not response.tool_calls:
                return response.content
            
            # Execute tool calls
            messages.append(response)
            
            for tool_call in response.tool_calls:
                tool_name = tool_call["name"]
                tool_args = tool_call["args"]
                
                logger.info(f"[Tool Call] {tool_name}({tool_args})")
                
                if tool_name in tool_map:
                    try:
                        result = await asyncio.to_thread(
                            tool_map[tool_name].invoke, tool_args
                        )
                        tool_result = json.dumps(result) if isinstance(result, dict) else str(result)
                    except Exception as e:
                        tool_result = f"Error executing {tool_name}: {str(e)}"
                        logger.error(f"Tool error: {e}")
                else:
                    tool_result = f"Unknown tool: {tool_name}"
                
                messages.append({
                    "role": "tool",
                    "tool_call_id": tool_call["id"],
                    "content": tool_result,
                })
        
        # Fallback if max iterations hit
        final = await self.llm.ainvoke(messages)
        return final.content


def load_config_from_env() -> dict:
    import os
    from dotenv import load_dotenv
    load_dotenv()
    return {
        "llm_model": os.getenv("LLM_MODEL", "meta-llama/Llama-3.1-8B-Instruct"),
        "llm_base_url": os.getenv("LLM_BASE_URL", "http://localhost:8001/v1"),
        "llm_api_key": os.getenv("LLM_API_KEY", "token"),
        "temperature": float(os.getenv("LLM_TEMPERATURE", "0.1")),
        "max_tokens": int(os.getenv("LLM_MAX_TOKENS", "4096")),
    }


async def main():
    from rich.console import Console
    from rich.prompt import Prompt
    
    console = Console()
    config = load_config_from_env()
    bot = UrbanAIChatbot(config)
    
    console.print("[bold green]🏙️ UrbanAI City Planning Assistant[/bold green]")
    console.print("[dim]Type 'exit' to quit | Powered by AMD Instinct MI300X + ROCm 7[/dim]\n")
    
    session_id = "cli_session"
    
    while True:
        user_input = Prompt.ask("[bold cyan]You[/bold cyan]")
        if user_input.lower() in ("exit", "quit"):
            break
        
        console.print("[bold yellow]UrbanAI:[/bold yellow] ", end="")
        async for chunk in bot.chat_stream(user_input, session_id):
            console.print(chunk, end="", highlight=False)
        console.print()


if __name__ == "__main__":
    asyncio.run(main())
