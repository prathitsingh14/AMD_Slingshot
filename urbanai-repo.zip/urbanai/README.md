# 🏙️ UrbanAI — AI-Powered City & Campus Planning Chatbot

An end-to-end AI platform for intelligent urban and campus planning, covering space utilization, footfall analytics, waste/water management, and greenery optimization. Built to run on **AMD Instinct MI300X / ROCm 7**.

---

## Architecture Overview

```
User Query
    │
    ▼
Chatbot Layer (LLM + Tool Calling)
    │
    ├─► Space Utilization Model
    ├─► Footfall / Clog Detection Model
    ├─► Waste & Water Prediction Model
    └─► Greenery / Soil Analysis Model
    │
    ▼
RAG Pipeline (Vector DB + Spatial Data)
    │
    ▼
Data Connectors (IoT / GIS / Sensors)
```

---

## Modules

| Module | Description | Key Tech |
|--------|-------------|----------|
| `chatbot/` | LLM orchestration, tool-calling, prompt engine | vLLM, LangChain |
| `models/space_utilization/` | Room occupancy forecasting, parking optimizer | PyTorch (ROCm) |
| `models/footfall/` | Pedestrian flow, clog point detection | YOLOv8, GNN |
| `models/waste_water/` | Waste yield predictor, water treatment recommender | Scikit-learn, LSTM |
| `models/greenery/` | Soil classifier, plant suitability recommender | XGBoost, spectral ML |
| `rag_pipeline/` | Document ingestion, vector store, retrieval | Qdrant, LlamaIndex |
| `data_connectors/` | IoT, GIS, satellite feed ingestion | MQTT, ESRI, GDAL |
| `api/` | FastAPI serving layer | FastAPI, Uvicorn |
| `dashboard/` | React frontend with maps and heatmaps | React, Leaflet |
| `eval/` | Benchmarks and accuracy metrics | pytest, MLflow |

---

## AMD Integration

- **AMD Instinct MI300X / MI350X** — primary inference and training GPUs (192–288GB HBM3)
- **ROCm 7** — GPU compute stack, replaces CUDA
- **AMD Quark** — FP4/FP8 quantization for edge/campus servers
- **AMD Inference Microservice (AIM)** — model serving orchestration
- **Ryzen AI** — local/on-campus inference for privacy-sensitive data

---

## Quick Start

```bash
# 1. Clone and set up
git clone https://github.com/your-org/urbanai.git
cd urbanai
pip install -r requirements.txt

# 2. Configure environment
cp config/example.env .env
# Edit .env with your API keys and sensor endpoints

# 3. Start the API server
uvicorn api.main:app --reload --port 8000

# 4. Start the chatbot
python chatbot/main.py

# 5. Launch dashboard
cd dashboard && npm install && npm start
```

---

## Hardware Requirements

| Environment | Recommended Hardware |
|-------------|---------------------|
| Development | AMD Radeon RX 7900 XTX / Ryzen AI laptop |
| On-campus server | AMD Radeon AI Pro R9700 (32GB) |
| Cloud / Production | AMD Instinct MI300X (192GB HBM3) |

---

## License
MIT
