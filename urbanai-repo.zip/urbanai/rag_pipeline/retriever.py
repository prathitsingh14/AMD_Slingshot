"""
UrbanAI RAG Pipeline — Document ingestion and retrieval for planning knowledge base.
Uses Qdrant vector DB with sentence-transformers embeddings.
"""

import asyncio
from pathlib import Path
from typing import Optional
from loguru import logger


class UrbanRAGRetriever:
    """
    Retrieves relevant urban planning documents, guidelines, and case studies
    to augment LLM responses with authoritative context.
    """
    
    def __init__(self, qdrant_host: str = "localhost", qdrant_port: int = 6333,
                 collection: str = "urbanai_knowledge"):
        self.collection = collection
        self._client = None
        self._embedder = None
        self._init_connections(qdrant_host, qdrant_port)

    def _init_connections(self, host: str, port: int):
        try:
            from qdrant_client import QdrantClient
            from sentence_transformers import SentenceTransformer
            self._client = QdrantClient(host=host, port=port)
            self._embedder = SentenceTransformer("all-MiniLM-L6-v2")
            logger.info(f"RAG: Connected to Qdrant at {host}:{port}")
        except Exception as e:
            logger.warning(f"RAG: Could not connect to Qdrant ({e}). Running without RAG context.")
            self._client = None

    async def retrieve(self, query: str, top_k: int = 5) -> str:
        """Retrieve relevant context for a query. Returns formatted context string."""
        if self._client is None:
            return ""
        
        try:
            loop = asyncio.get_event_loop()
            results = await loop.run_in_executor(None, self._search, query, top_k)
            
            if not results:
                return ""
            
            context_parts = []
            for r in results:
                payload = r.payload
                context_parts.append(
                    f"[Source: {payload.get('source', 'Unknown')}]\n"
                    f"{payload.get('text', '')}"
                )
            
            return "\n\n---\n\n".join(context_parts)
        
        except Exception as e:
            logger.error(f"RAG retrieval error: {e}")
            return ""

    def _search(self, query: str, top_k: int):
        query_vector = self._embedder.encode(query).tolist()
        return self._client.search(
            collection_name=self.collection,
            query_vector=query_vector,
            limit=top_k,
            score_threshold=0.6,
        )

    def ingest_documents(self, docs_dir: str = "data/planning_docs"):
        """
        Ingest planning documents into the vector store.
        Run this once to populate the knowledge base.
        """
        if self._client is None:
            logger.error("Cannot ingest: Qdrant not connected")
            return
        
        from qdrant_client.models import Distance, VectorParams, PointStruct
        import uuid
        
        # Create collection if not exists
        try:
            self._client.create_collection(
                collection_name=self.collection,
                vectors_config=VectorParams(size=384, distance=Distance.COSINE),
            )
            logger.info(f"Created Qdrant collection: {self.collection}")
        except Exception:
            logger.info("Collection already exists")
        
        docs_path = Path(docs_dir)
        if not docs_path.exists():
            logger.warning(f"Docs directory not found: {docs_dir}")
            return
        
        points = []
        for doc_file in docs_path.glob("**/*.txt"):
            text = doc_file.read_text(encoding="utf-8")
            # Chunk text into 512-char segments
            chunks = [text[i:i+512] for i in range(0, len(text), 512)]
            for chunk in chunks:
                if len(chunk.strip()) < 50:
                    continue
                vector = self._embedder.encode(chunk).tolist()
                points.append(PointStruct(
                    id=str(uuid.uuid4()),
                    vector=vector,
                    payload={"text": chunk, "source": doc_file.name},
                ))
        
        if points:
            self._client.upsert(collection_name=self.collection, points=points)
            logger.info(f"Ingested {len(points)} chunks from {docs_dir}")


class DocumentIngestionPipeline:
    """
    Handles ingestion of various document types into the RAG knowledge base.
    Supports PDF, TXT, and web scraping.
    """
    
    def __init__(self, retriever: UrbanRAGRetriever):
        self.retriever = retriever

    def ingest_from_directory(self, path: str):
        self.retriever.ingest_documents(path)
    
    def ingest_planning_guidelines(self):
        """
        Ingest standard urban planning guidelines.
        Add your planning documents to data/planning_docs/:
        - Smart Cities Mission guidelines
        - Campus planning standards (UGC, AICTE)
        - Water treatment standards (BIS, WHO)
        - Green building codes (LEED, GRIHA)
        - Waste management regulations (CPCB)
        """
        self.ingest_from_directory("data/planning_docs")
        logger.info("Planning guidelines ingestion complete")


if __name__ == "__main__":
    retriever = UrbanRAGRetriever()
    pipeline = DocumentIngestionPipeline(retriever)
    pipeline.ingest_planning_guidelines()
