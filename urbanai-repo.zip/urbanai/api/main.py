"""
UrbanAI FastAPI Server
REST API and WebSocket endpoints for chatbot, model queries, and sensor data.
"""

import os
import asyncio
from contextlib import asynccontextmanager
from datetime import datetime

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from loguru import logger

# ── Startup / Shutdown ────────────────────────────────────────────────────────

chatbot = None
iot_connector = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global chatbot, iot_connector
    
    logger.info("Starting UrbanAI API server...")
    
    # Initialize chatbot
    from chatbot.main import UrbanAIChatbot, load_config_from_env
    chatbot = UrbanAIChatbot(load_config_from_env())
    
    # Initialize IoT connector (mock for dev)
    from data_connectors.iot_connector import get_connector
    iot_connector = get_connector(use_mock=os.getenv("USE_MOCK_IOT", "true").lower() == "true")
    
    logger.info("UrbanAI API ready ✅")
    yield
    
    logger.info("Shutting down UrbanAI API...")


# ── App Setup ─────────────────────────────────────────────────────────────────

app = FastAPI(
    title="UrbanAI API",
    description="AI-powered city and campus planning platform",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "http://localhost:3000").split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Request/Response Models ───────────────────────────────────────────────────

class ChatRequest(BaseModel):
    message: str
    session_id: str = "default"

class ChatResponse(BaseModel):
    response: str
    session_id: str
    timestamp: str

class SpaceQuery(BaseModel):
    location: str
    time_horizon_hours: int = 24
    space_type: str = "all"

class FootfallQuery(BaseModel):
    zone: str = "all"
    detect_clog_points: bool = True
    time_of_day: str = None

class WasteQuery(BaseModel):
    area: str = "campus_wide"
    waste_type: str = "biodegradable"
    days_ahead: int = 7

class WaterQuery(BaseModel):
    zone: str
    sensor_data: dict = None

class GreeneryQuery(BaseModel):
    location: str
    soil_data: dict = None
    area_sqm: float = None


# ── Chat Endpoints ────────────────────────────────────────────────────────────

@app.post("/api/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    """Standard chat endpoint."""
    if not chatbot:
        raise HTTPException(503, "Chatbot not initialized")
    
    response = await chatbot.chat(req.message, req.session_id)
    return ChatResponse(
        response=response,
        session_id=req.session_id,
        timestamp=datetime.now().isoformat(),
    )


@app.post("/api/chat/stream")
async def chat_stream(req: ChatRequest):
    """Streaming chat endpoint using Server-Sent Events."""
    if not chatbot:
        raise HTTPException(503, "Chatbot not initialized")
    
    async def event_generator():
        async for chunk in chatbot.chat_stream(req.message, req.session_id):
            yield f"data: {chunk}\n\n"
        yield "data: [DONE]\n\n"
    
    return StreamingResponse(event_generator(), media_type="text/event-stream")


@app.websocket("/ws/chat/{session_id}")
async def chat_websocket(websocket: WebSocket, session_id: str):
    """WebSocket chat endpoint for real-time bidirectional chat."""
    await websocket.accept()
    logger.info(f"WebSocket connected: {session_id}")
    
    try:
        while True:
            data = await websocket.receive_json()
            message = data.get("message", "")
            
            if not message:
                continue
            
            # Stream response over WebSocket
            async for chunk in chatbot.chat_stream(message, session_id):
                await websocket.send_json({"type": "chunk", "content": chunk})
            
            await websocket.send_json({"type": "done"})
    
    except WebSocketDisconnect:
        logger.info(f"WebSocket disconnected: {session_id}")


# ── Domain Model Endpoints ────────────────────────────────────────────────────

@app.post("/api/space-utilization")
async def space_utilization(query: SpaceQuery):
    from models.space_utilization.predictor import SpaceUtilizationPredictor
    predictor = SpaceUtilizationPredictor.load_default()
    return predictor.predict(query.location, query.time_horizon_hours, query.space_type)


@app.post("/api/parking")
async def parking(lot_id: str = "all", forecast_hours: int = 2):
    from models.space_utilization.parking import ParkingPredictor
    predictor = ParkingPredictor.load_default()
    return predictor.get_availability(lot_id, forecast_hours)


@app.post("/api/footfall")
async def footfall(query: FootfallQuery):
    from models.footfall.analyzer import FootfallAnalyzer
    analyzer = FootfallAnalyzer.load_default()
    return analyzer.analyze(query.zone, query.detect_clog_points, query.time_of_day)


@app.post("/api/waste")
async def waste(query: WasteQuery):
    from models.waste_water.waste_predictor import WastePredictor
    predictor = WastePredictor.load_default()
    return predictor.predict(query.area, query.waste_type, query.days_ahead)


@app.post("/api/water")
async def water(query: WaterQuery):
    from models.waste_water.water_analyzer import WaterAnalyzer
    analyzer = WaterAnalyzer.load_default()
    return analyzer.analyze(query.zone, query.sensor_data)


@app.post("/api/greenery")
async def greenery(query: GreeneryQuery):
    from models.greenery.recommender import GreeneryRecommender
    recommender = GreeneryRecommender.load_default()
    return recommender.recommend(query.location, query.soil_data, query.area_sqm)


# ── GIS / Map Endpoints ───────────────────────────────────────────────────────

@app.get("/api/map/{query_type}")
async def map_data(query_type: str, bounds: str = None):
    from data_connectors.gis_connector import GISConnector
    gis = GISConnector()
    return gis.get_geojson(query_type, bounds)


# ── Sensor Data Endpoints ─────────────────────────────────────────────────────

@app.get("/api/sensors/latest")
async def sensors_latest():
    if not iot_connector:
        raise HTTPException(503, "IoT connector not initialized")
    return iot_connector.get_all_latest()


@app.get("/api/sensors/{sensor_type}/{zone_id}")
async def sensor_reading(sensor_type: str, zone_id: str):
    if not iot_connector:
        raise HTTPException(503, "IoT connector not initialized")
    reading = iot_connector.get_latest_reading(sensor_type, zone_id)
    if not reading:
        raise HTTPException(404, f"No data for {sensor_type}/{zone_id}")
    return reading


# ── Health Check ──────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    return {
        "status": "ok",
        "timestamp": datetime.now().isoformat(),
        "chatbot_ready": chatbot is not None,
        "iot_connected": iot_connector.is_connected if iot_connector else False,
        "version": "1.0.0",
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "api.main:app",
        host=os.getenv("API_HOST", "0.0.0.0"),
        port=int(os.getenv("API_PORT", "8000")),
        reload=True,
    )
